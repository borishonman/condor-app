﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Http;
using ModernHttpClient;

namespace Condor.Helpers
{
    class HttpClientFactory
    {
        public static HttpClient Create(Uri baseUri)
        {
            HttpClient res;
            if (baseUri.Scheme.Equals("http"))
                res = new HttpClient(new HttpClientHandler() { AllowAutoRedirect = false });
            else
                res = new HttpClient(new NativeMessageHandler());
            res.BaseAddress = baseUri;
            return res;
        }
    }
}
