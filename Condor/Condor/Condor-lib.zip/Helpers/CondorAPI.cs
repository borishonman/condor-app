﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using Condor.Models.API.CommandModels;
using Newtonsoft.Json.Linq;
using ModernHttpClient;
using System.Net.Http;
namespace Condor.Helpers
{
    class CondorAPI
    {
        private static CondorAPI m_theAPI = null;
        private string m_addr;
        private CondorHandlerThread m_thread;
        private string m_tok;

        public static CondorAPI getInstance()
        {
            if (m_theAPI == null)
                m_theAPI = new CondorAPI();
            return m_theAPI;
        }

        private CondorAPI()
        {
            
        }

        public void Initialize(string addr)
        {
            m_addr = addr;
            m_thread = new CondorHandlerThread(m_addr);
            m_thread.Start();
        }

        public void Execute(APICommand cmd)
        {
            cmd.Token = this.Token;
            m_thread.Enqueue(cmd);
        }

        public string Token
        {
            get
            {
                return m_tok;
            }
            set
            {
                m_tok = value;
            }
        }
    }
}
