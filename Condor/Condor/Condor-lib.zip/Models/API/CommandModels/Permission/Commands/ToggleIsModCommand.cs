﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission.Commands
{
    class ToggleIsModCommand : PermissionAPICommand
    {
        public ToggleIsModCommand()
        {
            this.Permission = "toggleismoderator";
        }
        public string Member
        {
            get
            {
                return m_data["userid"];
            }
            set
            {
                m_data["userid"] = value;
            }
        }
    }
}
