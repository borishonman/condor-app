﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission.Commands
{
    class CanManageTasksCommand : PermissionAPICommand
    {
        public CanManageTasksCommand()
        {
            this.Permission = "managetasks";
        }
        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }
    }
}
