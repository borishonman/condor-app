﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission.Commands
{
    class CanCreateProjectsCommand : PermissionAPICommand
    {
        public CanCreateProjectsCommand()
        {
            this.Permission = "createproject";
        }
    }
}
