﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission.Commands
{
    class CanModifyPermissionsCommand : PermissionAPICommand
    {
        public CanModifyPermissionsCommand()
        {
            this.Permission = "cantogglecreateproject";
        }
    }
}
