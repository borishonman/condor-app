﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission.Commands
{
    class CanDeleteProjectCommand : PermissionAPICommand
    {
        public CanDeleteProjectCommand()
        {
            this.Permission = "deleteproject";
        }
        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }
    }
}
