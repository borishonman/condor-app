﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission.Commands
{
    class GetPermTableCommand : PermissionAPICommand
    {
        public GetPermTableCommand()
        {
            this.Permission = "getmemberpermissiontable";
        }
    }
}
