﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission.Commands
{
    class ToggleCreatePermissionCommand : PermissionAPICommand
    {
        public ToggleCreatePermissionCommand()
        {
            this.Permission = "togglecreateproject";
        }
        public string Member
        {
            get
            {
                return m_data["userid"];
            }
            set
            {
                m_data["userid"] = value;
            }
        }
    }
}
