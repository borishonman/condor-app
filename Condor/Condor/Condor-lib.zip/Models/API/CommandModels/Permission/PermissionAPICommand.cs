﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Permission
{
    class PermissionAPICommand : APICommand
    {
        public PermissionAPICommand()
        {
            m_ep = Endpoint.PERMISSION;
        }

        protected string Permission
        {
            get
            {
                return m_data["permission"];
            }
            set
            {
                m_data["permission"] = value;
            }
        }
    }
}
