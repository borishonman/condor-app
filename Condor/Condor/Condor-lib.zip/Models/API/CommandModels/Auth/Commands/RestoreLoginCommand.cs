﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Auth.Commands
{
    class RestoreLoginCommand : AuthAPICommand
    {
        public RestoreLoginCommand()
        {
            this.Function = "restorelogin";
        }
    }
}
