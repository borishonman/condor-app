﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Auth.Commands
{
    class LogoutCommand : AuthAPICommand
    {
        public LogoutCommand()
        {
            this.Function = "logout";
        }
    }
}
