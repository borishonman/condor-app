﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Auth.Commands
{
    class LoginCommand : AuthAPICommand
    {
        public LoginCommand()
        {
            this.Function = "login";
            this.Token = "";
        }

        public string Username
        {
            get
            {
                return m_data["username"];
            }
            set
            {
                m_data["username"] = value;
            }
        }
        public string Password
        {
            get
            {
                return m_data["password"];
            }
            set
            {
                m_data["password"] = value;
            }
        }
    }
}
