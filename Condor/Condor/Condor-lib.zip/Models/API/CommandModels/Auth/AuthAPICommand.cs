﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Auth
{
    class AuthAPICommand : APICommand
    {
        public AuthAPICommand()
        {
            m_ep = Endpoint.AUTH;
        }
        protected String Function
        {
            get
            {
                return m_data["function"];
            }
            set
            {
                m_data["function"] = value;
            }
        }
    }
}
