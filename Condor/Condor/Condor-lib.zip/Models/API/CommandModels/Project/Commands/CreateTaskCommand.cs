﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Project.Commands
{
    class CreateTaskCommand : ProjectAPICommand
    {
        public CreateTaskCommand()
        {
            this.Function = "createtask";
        }

        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }

        public string Title
        {
            get
            {
                return m_data["name"];
            }
            set
            {
                m_data["name"] = value;
            }
        }

        public DateTime Due
        {
            get
            {
                return new DateTime(int.Parse(m_data["due"])*1000);
            }
            set
            {
                m_data["due"] = (value.ToUniversalTime().Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc))).TotalSeconds.ToString();
            }
        }

        public string Description
        {
            get
            {
                return m_data["desc"];
            }
            set
            {
                m_data["desc"] = value;
            }
        }
    }
}
