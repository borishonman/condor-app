﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Project.Commands
{
    class SetTaskDueCommand : ProjectAPICommand
    {
        public SetTaskDueCommand()
        {
            this.Function = "editdate";
        }
        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }
        public string Task
        {
            get
            {
                return m_data["task"];
            }
            set
            {
                m_data["task"] = value;
            }
        }
        public DateTime Due
        {
            get
            {
                return new DateTime(int.Parse(m_data["date"]) * 1000);
            }
            set
            {
                m_data["date"] = (value.ToUniversalTime().Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc ))).TotalSeconds.ToString();
            }
        }
    }
}
