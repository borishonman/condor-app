﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Project.Commands
{
    class AssignTaskCommand : ProjectAPICommand
    {
        public AssignTaskCommand()
        {
            this.Function = "assign";
        }

        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }

        public string Task
        {
            get
            {
                return m_data["task"];
            }
            set
            {
                m_data["task"] = value;
            }
        }

        public string Member
        {
            get
            {
                return m_data["member"];
            }
            set
            {
                m_data["member"] = value;
            }
        }
    }
}
