﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Project.Commands
{
    class SetTaskStatusCommand : ProjectAPICommand
    {
        public SetTaskStatusCommand()
        {
            this.Function = "status";
        }
        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }
        public string Task
        {
            get
            {
                return m_data["task"];
            }
            set
            {
                m_data["task"] = value;
            }
        }
        public string Status
        {
            get
            {
                return m_data["status"];
            }
            set
            {
                m_data["status"] = value;
            }
        }
    }
}
