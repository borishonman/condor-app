﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Project.Commands
{
    class DeleteTaskCommand : ProjectAPICommand
    {
        public DeleteTaskCommand()
        {
            this.Function = "deletetask";
        }

        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }

        public string Title
        {
            get
            {
                return m_data["name"];
            }
            set
            {
                m_data["name"] = value;
            }
        }
    }
}
