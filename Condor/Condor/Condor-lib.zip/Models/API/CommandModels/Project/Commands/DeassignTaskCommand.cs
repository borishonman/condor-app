﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Project.Commands
{
    class DeassignTaskCommand : ProjectAPICommand
    {
        public DeassignTaskCommand()
        {
            this.Function = "deassign";
        }
        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }
        public string Task
        {
            get
            {
                return m_data["task"];
            }
            set
            {
                m_data["task"] = value;
            }
        }
    }
}
