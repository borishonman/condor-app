﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Project.Commands
{
    class GetAllProjectsCommand : ProjectAPICommand
    {
        public GetAllProjectsCommand()
        {
            this.Function = "getprojectlist";
        }
    }
}
