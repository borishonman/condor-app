﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Member
{
    class MemberAPICommand : APICommand
    {
        protected MemberAPICommand()
        {
            m_ep = Endpoint.MEMBER;
        }

        protected String Function
        {
            get
            {
                return m_data["function"];
            }
            set
            {
                m_data["function"] = value;
            }
        }
    }
}
