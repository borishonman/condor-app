﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Member.Commands
{
    class DeleteMemberCommand : MemberAPICommand
    {
        public DeleteMemberCommand()
        {
            this.Function = "delete";
        }
        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }
        public string Member
        {
            get
            {
                return m_data["member"];
            }
            set
            {
                m_data["member"] = value;
            }
        }
    }
}
