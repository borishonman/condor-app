﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Condor.Models.API.CommandModels.Member.Commands
{
    class PromoteMemberCommand : MemberAPICommand
    {
        public PromoteMemberCommand()
        {
            this.Function = "promote";
        }

        public string Project
        {
            get
            {
                return m_data["project"];
            }
            set
            {
                m_data["project"] = value;
            }
        }
        public string Member
        {
            get
            {
                return m_data["member"];
            }
            set
            {
                m_data["member"] = value;
            }
        }
    }
}
